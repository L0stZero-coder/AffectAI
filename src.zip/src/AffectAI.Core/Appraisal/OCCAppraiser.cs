using AffectAI.Core.Emotion;
using AffectAI.Core.Interfaces;

namespace AffectAI.Core.Appraisal;

/// <summary>
/// Very small OCC-like appraiser. Maps event to VAD delta + label.
/// </summary>
public class OCCAppraiser
{
    public (EmotionVector delta, string label) Appraise(IEvent e, Personality p, EmotionState s)
    {
        // Base mapped by goal impact and salience
        var impact = Math.Clamp(e.GoalImpact, -1, 1) * Math.Clamp(e.Salience, 0, 1);
        // Personality sensitivity
        var k = p.Sensitivity();

        // Heuristics: goal+ -> joy/hope; goal- -> frustration/fear
        EmotionVector delta;
        string label;
        if (impact > 0)
        {
            delta = new EmotionVector(+0.3 * impact * k, +0.1 * impact * k, +0.15 * impact * k);
            label = impact > 0.6 ? "joy" : "hope";
        }
        else if (impact < 0)
        {
            var m = -impact;
            delta = new EmotionVector(-0.35 * m * k, +0.15 * m * k, -0.2 * m * k);
            label = m > 0.6 ? "fear" : "frustration";
        }
        else
        {
            delta = new EmotionVector(0, 0.02 * k, 0); // small arousal bump for neutral novelty
            label = "surprise";
        }

        // Text cues can further modulate (very light sentiment hook handled in TextIngestor)
        return (delta.Clamp(), label);
    }
}
