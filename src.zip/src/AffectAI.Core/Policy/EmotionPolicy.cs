using AffectAI.Core.Emotion;
using AffectAI.Core.Interfaces;

namespace AffectAI.Core.Policy;

/// <summary>
/// Maps emotional state to decision parameters and re-scores actions.
/// </summary>
public class EmotionPolicy
{
    public record PolicyOut(double ExplorationRate, double RiskTolerance, string Tone);

    public PolicyOut Derive(EmotionState s)
    {
        var v = s.Current.Valence; var a = s.Current.Arousal; var d = s.Current.Dominance;
        var exploration = 0.2 + 0.4 * Math.Max(0, v) + 0.2 * Math.Max(0, a);
        var risk = 0.3 + 0.4 * Math.Max(0, d) - 0.2 * Math.Max(0, -v);
        string tone = v switch
        {
            > 0.4 => "warm",
            < -0.4 => "concerned",
            _ => a > 0.3 ? "energetic" : "neutral"
        };
        return new PolicyOut(
            Math.Clamp(exploration, 0.05, 0.95),
            Math.Clamp(risk, 0.05, 0.95),
            tone
        );
    }

    public IEnumerable<IAction> ReScore(IEnumerable<IAction> actions, EmotionState s)
    {
        var p = Derive(s);
        foreach (var a in actions)
        {
            // Simple adjustment: valence boosts cooperative actions, dominance boosts assertive ones
            var boost = 0.0;
            if (a.Name.Contains("help", StringComparison.OrdinalIgnoreCase)) boost += Math.Max(0, s.Current.Valence) * 0.2;
            if (a.Name.Contains("assert", StringComparison.OrdinalIgnoreCase)) boost += Math.Max(0, s.Current.Dominance) * 0.2;
            if (a.Name.Contains("avoid", StringComparison.OrdinalIgnoreCase)) boost += Math.Max(0, -s.Current.Arousal) * 0.1;
            a.UtilityEstimate += boost;
            yield return a;
        }
    }
}
