using AffectAI.Core.Interfaces;
using AffectAI.Core.Policy;

namespace AffectAI.Core.Reasoner;

public class SimpleReasoner
{
    private readonly EmotionPolicy _policy = new();

    public (IAction chosen, EmotionPolicy.PolicyOut policy) ChooseAction(IEnumerable<IAction> actions, AffectAI.Core.Emotion.EmotionState s)
    {
        var rescored = _policy.ReScore(actions, s).OrderByDescending(a => a.UtilityEstimate).ToList();
        var policy = _policy.Derive(s);
        var chosen = rescored.First();
        return (chosen, policy);
    }
}
