using AffectAI.Core.Emotion;

namespace AffectAI.Core.Storage;

public static class StateStore
{
    public static void Save(string path, EmotionState state)
    {
        File.WriteAllText(path, state.Serialize());
    }

    public static EmotionState Load(string path)
    {
        var json = File.ReadAllText(path);
        return EmotionState.Deserialize(json);
    }
}
