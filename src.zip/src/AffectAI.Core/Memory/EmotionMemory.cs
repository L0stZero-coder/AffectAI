namespace AffectAI.Core.Memory;

public class EmotionMemory
{
    private readonly Queue<(DateTime ts, string label, double intensity)> _recent = new();
    private readonly int _max = 200;

    public void Push(string label, double intensity)
    {
        _recent.Enqueue((DateTime.UtcNow, label, intensity));
        while (_recent.Count > _max) _recent.Dequeue();
    }

    public IEnumerable<(DateTime ts, string label, double intensity)> Recent() => _recent;
}
