using System.Text.RegularExpressions;
using AffectAI.Core.Emotion;

namespace AffectAI.Core.Ingestion;

/// <summary>
/// Lightweight online lexicon with per-word V/A weights. Can be trained incrementally from feedback.
/// </summary>
public class TextIngestor
{
    private readonly Dictionary<string, (double v, double a)> _lex = new(StringComparer.OrdinalIgnoreCase)
    {
        ["good"] = (0.4, 0.1), ["great"] = (0.6, 0.2), ["love"] = (0.7, 0.3), ["win"] = (0.5, 0.2),
        ["bad"] = (-0.5, 0.2), ["hate"] = (-0.7, 0.3), ["fail"] = (-0.6, 0.2), ["error"] = (-0.4, 0.2),
        ["urgent"] = (0.0, 0.4), ["warning"] = (-0.2, 0.4), ["blocked"] = (-0.4, 0.3), ["success"] = (0.6, 0.2)
    };

    private readonly double _learnRate;

    public TextIngestor(double learnRate = 0.1)
    {
        _learnRate = Math.Clamp(learnRate, 0.01, 1.0);
    }

    public EmotionVector Analyze(string? text, double scale = 1.0)
    {
        if (string.IsNullOrWhiteSpace(text)) return new EmotionVector(0, 0, 0);
        var tokens = Tokenize(text);
        double v = 0, a = 0; int c = 0;
        foreach (var t in tokens)
        {
            if (_lex.TryGetValue(t, out var w)) { v += w.v; a += w.a; c++; }
        }
        if (c == 0) return new EmotionVector(0, 0, 0);
        var avgV = v / c; var avgA = a / c;
        return new EmotionVector(avgV * scale, avgA * scale, 0);
    }

    public void LearnFromFeedback(string wordOrPhrase, EmotionVector target)
    {
        foreach (var t in Tokenize(wordOrPhrase))
        {
            var (cv, ca) = _lex.TryGetValue(t, out var cur) ? cur : (0.0, 0.0);
            // Move current weights towards target valence/arousal
            var nv = cv + _learnRate * (target.Valence - cv);
            var na = ca + _learnRate * (target.Arousal - ca);
            _lex[t] = (Math.Clamp(nv, -1, 1), Math.Clamp(na, -1, 1));
        }
    }

    public IEnumerable<(string token, (double v, double a) weights)> TopWeights(int n = 20)
        => _lex.OrderByDescending(kv => Math.Abs(kv.Value.v) + Math.Abs(kv.Value.a)).Take(n)
               .Select(kv => (kv.Key, kv.Value));

    private static IEnumerable<string> Tokenize(string s)
    {
        foreach (Match m in Regex.Matches(s.ToLowerInvariant(), "[a-z']+"))
            yield return m.Value;
    }
}
