namespace AffectAI.Core.Interfaces;

public interface IAction
{
    string Name { get; }
    string? Payload { get; }
    double UtilityEstimate { get; set; }
}
