namespace AffectAI.Core.Interfaces;

public interface IEvent
{
    string Type { get; }
    string? Text { get; }
    double Salience { get; } // importance in [0,1]
    // Optional goal alignment score in [-1,1]; positive helps goals, negative hinders
    double GoalImpact { get; }
}
