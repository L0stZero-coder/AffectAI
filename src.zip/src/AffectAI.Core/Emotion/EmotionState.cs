using System.Text.Json;

namespace AffectAI.Core.Emotion;

public class EmotionState
{
    public EmotionVector Baseline { get; private set; }
    public EmotionVector Current { get; private set; }

    // Decay factors per tick (0..1). Higher = faster return to baseline
    public double Decay { get; set; } = 0.02;

    public EmotionState(EmotionVector baseline)
    {
        Baseline = baseline.Clamp();
        Current = baseline.Clamp();
    }

    public void ApplyDelta(EmotionVector delta)
    {
        Current = (Current + delta).Clamp();
    }

    public void TickDecay()
    {
        // Exponential decay towards baseline
        var dV = (Baseline.Valence - Current.Valence) * Decay;
        var dA = (Baseline.Arousal - Current.Arousal) * Decay;
        var dD = (Baseline.Dominance - Current.Dominance) * Decay;
        Current = new EmotionVector(Current.Valence + dV, Current.Arousal + dA, Current.Dominance + dD).Clamp();
    }

    public string Serialize() => JsonSerializer.Serialize(this);

    public static EmotionState Deserialize(string json)
    {
        var dto = JsonSerializer.Deserialize<EmotionStateDto>(json)!;
        var st = new EmotionState(new EmotionVector(dto.BaselineV, dto.BaselineA, dto.BaselineD))
        {
            Decay = dto.Decay
        };
        st.Current = new EmotionVector(dto.CurrentV, dto.CurrentA, dto.CurrentD).Clamp();
        return st;
    }

    private record EmotionStateDto(double BaselineV, double BaselineA, double BaselineD, double CurrentV, double CurrentA, double CurrentD, double Decay)
    {
        public EmotionStateDto() : this(0,0,0,0,0,0,0) {}
    }
}
