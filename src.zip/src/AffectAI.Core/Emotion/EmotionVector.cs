namespace AffectAI.Core.Emotion;

/// <summary>
/// Valence-Arousal-Dominance vector with basic ops.
/// </summary>
public readonly record struct EmotionVector(double Valence, double Arousal, double Dominance)
{
    public EmotionVector Clamp()
        => new(
            Math.Clamp(Valence, -1, 1),
            Math.Clamp(Arousal, -1, 1),
            Math.Clamp(Dominance, -1, 1)
        );

    public static EmotionVector operator +(EmotionVector a, EmotionVector b)
        => new(a.Valence + b.Valence, a.Arousal + b.Arousal, a.Dominance + b.Dominance);

    public static EmotionVector operator *(EmotionVector a, double k)
        => new(a.Valence * k, a.Arousal * k, a.Dominance * k);

    public override string ToString()
        => $"V:{Valence:F2} A:{Arousal:F2} D:{Dominance:F2}";
}
