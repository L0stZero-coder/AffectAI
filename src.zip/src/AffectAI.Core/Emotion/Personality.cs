namespace AffectAI.Core.Emotion;

/// <summary>
/// Big-5-inspired traits (0..1). Mapped to baseline and sensitivity.
/// </summary>
public class Personality
{
    public double Openness { get; init; } = 0.5;
    public double Conscientiousness { get; init; } = 0.5;
    public double Extraversion { get; init; } = 0.5;
    public double Agreeableness { get; init; } = 0.5;
    public double Neuroticism { get; init; } = 0.5;

    public EmotionVector Baseline()
    {
        // Map traits to baseline VAD heuristically
        var valence = 0.1 * (Agreeableness + Extraversion) - 0.1 * Neuroticism;
        var arousal = 0.1 * (Extraversion + Openness) - 0.05 * Conscientiousness;
        var dominance = 0.1 * (Conscientiousness + Extraversion) - 0.1 * Neuroticism;
        return new EmotionVector(valence, arousal, dominance).Clamp();
    }

    public double Sensitivity() => 0.5 + 0.5 * Neuroticism; // higher N -> more reactive
}
