using AffectAI.Core.Appraisal;
using AffectAI.Core.Emotion;
using AffectAI.Core.Ingestion;
using AffectAI.Core.Interfaces;
using AffectAI.Core.Reasoner;

namespace AffectAI.ConsoleDemo;

public class SimpleEvent : IEvent
{
    public required string Type { get; init; }
    public string? Text { get; init; }
    public double Salience { get; init; }
    public double GoalImpact { get; init; }
}

public class SimpleAction : IAction
{
    public required string Name { get; init; }
    public string? Payload { get; init; }
    public double UtilityEstimate { get; set; }
}

public static class Program
{
    public static void Main()
    {
        Console.WriteLine("AffectAI Demo — Emotion-Driven Agent\n");

        // 1) Configure personality & state
        var persona = new Personality { Openness = 0.7, Conscientiousness = 0.6, Extraversion = 0.65, Agreeableness = 0.6, Neuroticism = 0.35 };
        var state = new EmotionState(persona.Baseline()) { Decay = 0.03 };
        var memory = new AffectAI.Core.Memory.EmotionMemory();
        var appraiser = new OCCAppraiser();
        var ingestor = new TextIngestor(learnRate: 0.15);
        var reasoner = new SimpleReasoner();

        while (true)
        {
            Console.WriteLine($"Current state: {state.Current} (baseline {state.Baseline})");
            Console.WriteLine("Enter an event text (or 'quit'):");
            var text = Console.ReadLine();
            if (string.Equals(text, "quit", StringComparison.OrdinalIgnoreCase)) break;

            Console.Write("Salience 0..1: ");
            var salStr = Console.ReadLine();
            double.TryParse(salStr, out var salience);
            salience = Math.Clamp(salience, 0, 1);

            Console.Write("GoalImpact -1..1: ");
            var impStr = Console.ReadLine();
            double.TryParse(impStr, out var impact);
            impact = Math.Clamp(impact, -1, 1);

            // 2) Appraise event
            var evt = new SimpleEvent { Type = "text", Text = text, Salience = salience, GoalImpact = impact };
            var (delta, label) = appraiser.Appraise(evt, persona, state);

            // 3) Modulate with text lexicon analysis
            var textDelta = ingestor.Analyze(text, scale: 0.5 * salience);
            var finalDelta = new EmotionVector(
                delta.Valence + textDelta.Valence,
                delta.Arousal + textDelta.Arousal,
                delta.Dominance // dominance from text omitted for simplicity
            ).Clamp();

            state.ApplyDelta(finalDelta);
            memory.Push(label, Math.Abs(impact));
            Console.WriteLine($"Appraised '{label}', applied Δ {finalDelta}. New state: {state.Current}\n");

            // 4) Choose an action influenced by state
            var actions = new List<SimpleAction>
            {
                new() { Name = "help_user", UtilityEstimate = 0.6 },
                new() { Name = "assert_policy", UtilityEstimate = 0.55 },
                new() { Name = "avoid_risk", UtilityEstimate = 0.5 },
                new() { Name = "explore_new_idea", UtilityEstimate = 0.52 }
            };
            var (chosen, policy) = reasoner.ChooseAction(actions, state);
            Console.WriteLine($"Policy: exploration={policy.ExplorationRate:F2}, risk={policy.RiskTolerance:F2}, tone={policy.Tone}");
            Console.WriteLine($"Chosen action: {chosen.Name} (utility {chosen.UtilityEstimate:F2})\n");

            // 5) Optional: human feedback to improve lexicon
            Console.Write("Feedback? (format: 'word: v a' where v,a in [-1,1] or empty to skip): ");
            var fb = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(fb) && fb.Contains(':'))
            {
                var parts = fb.Split(':', 2);
                var word = parts[0].Trim();
                var nums = parts[1].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (nums.Length >= 2 && double.TryParse(nums[0], out var v) && double.TryParse(nums[1], out var a))
                {
                    ingestor.LearnFromFeedback(word, new EmotionVector(v, a, 0));
                    Console.WriteLine($"Learned weighting for '{word}'.\n");
                }
            }

            // 6) decay towards baseline between turns
            state.TickDecay();
        }
    }
}
